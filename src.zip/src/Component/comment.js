
import React, { Component } from 'react'

class comment extends Component {
    render() {
        return (
            <div>

                 <h4>{this.props.mycomment}</h4>
            </div>

        )
    }
}
export default comment;