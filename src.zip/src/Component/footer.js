

import React, { Component } from 'react'

class footer extends Component {
    render() {
        return (
            <div>
               
               <h2>{this.props.myfooter}</h2>
            </div>
        )
    }
}
export default footer;