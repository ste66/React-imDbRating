
import React from 'react'

function navbar(props) {
    return (
        <div>
            <h2>{props.mynavbar} by IMDb Users </h2>
        </div>
    )
}
export default navbar;
